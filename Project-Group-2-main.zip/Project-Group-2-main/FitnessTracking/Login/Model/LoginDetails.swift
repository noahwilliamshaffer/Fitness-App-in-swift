//
//  LoginDetails.swift
//  FitnessTracking
//
//  Created by Jalal Jean-Charles on 11/5/22.
//

import Foundation

struct LoginDetails{
    var email : String
    var password : String
}
